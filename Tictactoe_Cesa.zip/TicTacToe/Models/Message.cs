﻿namespace TicTacToe.Models
{
    public class Message
    {
        public string Type { get; set; }      // e.g., "Register", "Invite", "Accept", "Move", "Quit"
        public string Username { get; set; }  // For "Register" messages.
        public string Sender { get; set; }    // For "Invite", "Accept", "Move", "Quit"
        public string Opponent { get; set; }  // For "Invite" and "Accept" messages.
        public int Cell { get; set; }         // For "Move": the cell index.
        public string Symbol { get; set; }    // For "Move": "X" or "O".
        public string GameId { get; set; }    // For "Move" and "Quit".
    }

}
