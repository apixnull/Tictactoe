﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using TicTacToe.Models;

namespace TicTacToe.Models
{
    public class User
    {
        [Key]
        public int Id { get; set; }

        [Required, StringLength(50)]
        public string Username { get; set; } = string.Empty;

        [Required, StringLength(255)]
        public string Password { get; set; } = string.Empty;

        [NotMapped]
        [Compare("Password", ErrorMessage = "Passwords do not match.")]
        public string? ConfirmPassword { get; set; }

        public int TotalGames { get; set; } = 0;
        public int MultiplayerGamesPlayed { get; set; } = 0;
        public int MultiplayerWins { get; set; } = 0;
        public int RankPoints { get; set; } = 0;
        public int WinningStreak { get; set; } = 0;

        [Required, StringLength(20)]
        public string Rank { get; set; } = "NewBreed";

        public double WinRate => MultiplayerGamesPlayed > 0
            ? (double)MultiplayerWins / MultiplayerGamesPlayed * 100
            : 0;

        // ✅ Fix: Define the correct relationship with MatchHistory
        public virtual List<MatchHistory> MatchHistories { get; set; } = new();

        public void UpdateRank()
        {
            if (RankPoints >= 500) Rank = "God of All Gods";
            else if (RankPoints >= 400) Rank = "God";
            else if (RankPoints >= 300) Rank = "Prophet";
            else if (RankPoints >= 200) Rank = "Mathematician";
            else if (RankPoints >= 100) Rank = "Challenger";
            else Rank = "NewBreed";
        }
    }
}
