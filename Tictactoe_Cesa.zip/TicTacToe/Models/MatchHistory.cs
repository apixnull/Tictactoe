﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TicTacToe.Models
{
    public class MatchHistory
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int UserId { get; set; }  // ✅ This is the proper foreign key

        [ForeignKey("UserId")] // ✅ Ensures EF Core maps the relationship correctly
        public virtual User User { get; set; }

        public string Opponent { get; set; } = "Unknown";
        public bool IsWin { get; set; }
        public DateTime DatePlayed { get; set; } = DateTime.UtcNow;
    }
}
