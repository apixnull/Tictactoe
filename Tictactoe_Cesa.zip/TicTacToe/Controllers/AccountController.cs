﻿using Microsoft.AspNetCore.Mvc;
using TicTacToe.Data;
using TicTacToe.Models;
using System.Security.Cryptography;
using System.Text;

namespace TicTacToe.Controllers
{
    public class AccountController : Controller
    {
        private readonly AppDbContext _context;

        public AccountController(AppDbContext context)
        {
            _context = context;
        }

        // GET: Register Page
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(User model)
        {
            if (_context.Users.Any(u => u.Username == model.Username))
            {
                TempData["ErrorMessage"] = "Username already exists!";
                return RedirectToAction("Register");
            }

            if (model.Password != model.ConfirmPassword)
            {
                TempData["ErrorMessage"] = "Passwords do not match!";
                return RedirectToAction("Register");
            }

            string hashedPassword = HashPassword(model.Password);
            var newUser = new User
            {
                Username = model.Username,
                Password = hashedPassword,
                TotalGames = 0,
                MultiplayerGamesPlayed = 0,
                MultiplayerWins = 0,
                RankPoints = 0,
                WinningStreak = 0,
                Rank = "NewBreed",
                MatchHistories = new List<MatchHistory>() // Initialize empty match history
            };

            _context.Users.Add(newUser);
            _context.SaveChanges();

            // Automatically log in the user after registration
            HttpContext.Session.SetString("Username", newUser.Username);

            TempData["SuccessMessage"] = "Registration successful! Welcome, " + newUser.Username;
            return RedirectToAction("Index", "Home");
        }



        // GET: Login Page
        public IActionResult Login()
        {
            return View();
        }

        // POST: Handle Login
        [HttpPost]
        public IActionResult Login(User model)
        {
            if (string.IsNullOrWhiteSpace(model.Username) || string.IsNullOrWhiteSpace(model.Password))
            {
                TempData["ErrorMessage"] = "Username and password are required!";
                return RedirectToAction("Login");
            }

            // Check if the user exists
            var user = _context.Users.FirstOrDefault(u => u.Username == model.Username);

            if (user == null)
            {
                TempData["ErrorMessage"] = "Account does not exist!";
                return RedirectToAction("Login");
            }

            // Hash the entered password and compare with the stored password
            string hashedPassword = HashPassword(model.Password);
            if (user.Password != hashedPassword)
            {
                TempData["ErrorMessage"] = "Invalid password!";
                return RedirectToAction("Login");
            }

            // Login successful
            HttpContext.Session.SetString("Username", user.Username);
            TempData["SuccessMessage"] = "Login successful! Welcome, " + user.Username;
            return RedirectToAction("Index", "Home");
        }



        // Logout
        public IActionResult Logout()
        {
            HttpContext.Session.Remove("Username");
            TempData["SuccessMessage"] = "You have been logged out successfully.";
            return RedirectToAction("Login");
        }

        // Hash password using SHA256
        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = Encoding.UTF8.GetBytes(password);
                byte[] hash = sha256.ComputeHash(bytes);
                return Convert.ToBase64String(hash);
            }
        }
    }
}
