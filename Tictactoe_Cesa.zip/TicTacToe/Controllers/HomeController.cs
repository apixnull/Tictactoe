﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TicTacToe.Data;
using TicTacToe.Models;

namespace TicTacToe.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _context;

        public HomeController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Profile()
        {
            // 🔹 Get the username from session safely
            if (!HttpContext.Session.TryGetValue("Username", out var usernameBytes))
            {
                TempData["ErrorMessage"] = "You need to log in to view your profile.";
                return RedirectToAction("Login", "Account");
            }

            string username = System.Text.Encoding.UTF8.GetString(usernameBytes);

            // 🔹 Check if username is empty (avoids empty queries)
            if (string.IsNullOrEmpty(username))
            {
                TempData["ErrorMessage"] = "Invalid session. Please log in again.";
                return RedirectToAction("Login", "Account");
            }

            // 🔹 Query the database safely
            var user = _context.Users
                .Include(u => u.MatchHistories) // ✅ Ensure MatchHistories is loaded
                .FirstOrDefault(u => u.Username == username); // ✅ Prevents exception if user does not exist

            if (user == null)
            {
                TempData["ErrorMessage"] = "User not found.";
                return RedirectToAction("Login", "Account"); // ✅ Redirects to login
            }

            return View(user);
        }

        // ✅ Global Error Page
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
