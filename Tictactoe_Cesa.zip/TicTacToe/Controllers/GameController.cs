﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using TicTacToe.Data;
using TicTacToe.Models;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace TicTacToe.Controllers
{
    public class GameController : Controller
    {
        private readonly AppDbContext _context;

        public GameController(AppDbContext context)
        {
            _context = context;
        }

        // ✅ Helper function to get the logged-in user
        private User? GetLoggedInUser()
        {
            var username = HttpContext.Session.GetString("Username");
            return _context.Users.FirstOrDefault(u => u.Username == username);
        }

        // ✅ Action to check if an opponent exists
        [HttpGet]
        public IActionResult CheckUserExists(string username)
        {
            bool exists = _context.Users.Any(u => u.Username == username);
            return Json(new { exists });
        }

        [HttpGet]
        public IActionResult GetUserStats(string username)
        {
            var user = _context.Users.FirstOrDefault(u => u.Username == username);

            if (user == null)
            {
                return Json(new { exists = false });
            }

            return Json(new
            {
                exists = true,
                winRate = user.WinRate,
                matchesPlayed = user.MultiplayerGamesPlayed,
                wins = user.MultiplayerWins,
                rank = user.Rank
            });
        }

        // ✅ Save match history when a multiplayer game ends
        [HttpPost]
        public async Task<IActionResult> SaveMatchHistory([FromBody] MatchHistoryRequest request)
        {
            var user = GetLoggedInUser();
            if (user == null)
            {
                return Unauthorized(new { message = "User is not logged in." });
            }

            // ✅ Find the opponent
            var opponent = _context.Users.FirstOrDefault(u => u.Username == request.Opponent);
            if (opponent == null)
            {
                return NotFound(new { message = "Opponent not found." });
            }

            // ✅ Determine if the user won, lost, or drew
            bool isDraw = request.Result.ToLower() == "draw";
            bool isUserWin = request.Result.Contains(user.Username);

            // ✅ Update user stats
            user.TotalGames++;
            user.MultiplayerGamesPlayed++;
            if (isUserWin)
            {
                user.MultiplayerWins++;
                user.RankPoints += 10;
                user.WinningStreak++;
            }
            else if (!isDraw)
            {
                user.WinningStreak = 0;
            }

            // ✅ Update opponent stats
            opponent.TotalGames++;
            opponent.MultiplayerGamesPlayed++;
            if (!isDraw && !isUserWin)
            {
                opponent.MultiplayerWins++;
                opponent.RankPoints += 10;
                opponent.WinningStreak++;
            }
            else if (!isDraw)
            {
                opponent.WinningStreak = 0;
            }

            // ✅ Save match history for both players
            var matchUser = new MatchHistory
            {
                UserId = user.Id,
                Opponent = opponent.Username,
                IsWin = isUserWin,
                DatePlayed = DateTime.UtcNow
            };

            var matchOpponent = new MatchHistory
            {
                UserId = opponent.Id,
                Opponent = user.Username,
                IsWin = !isUserWin && !isDraw, // Opponent wins if the user loses
                DatePlayed = DateTime.UtcNow
            };

            _context.MatchHistories.Add(matchUser);
            _context.MatchHistories.Add(matchOpponent);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Match history saved successfully." });
        }


        // ✅ Multiplayer mode (Requires account)
        public IActionResult Multiplayer()
        {
            var user = GetLoggedInUser();
            if (user == null)
            {
                TempData["ErrorMessage"] = "To play in Multiplayer Mode, please create an account first or log in!";
                return RedirectToAction("Register", "Account");
            }

            ViewData["Username"] = user.Username;
            return View();
        }

        // ✅ Guest Mode - Can only play against the bot
        public IActionResult GuestPlaying()
        {
            return View();
        }

        // ✅ Play against a Random Bot
        public IActionResult RandomBot()
        {
            var user = GetLoggedInUser();
            if (user == null)
            {
                return RedirectToAction("GuestPlaying");
            }

            user.TotalGames++;
            _context.SaveChanges();

            return View();
        }

        // ✅ Play against AI (Requires account)
        public IActionResult PlayAi()
        {
            var user = GetLoggedInUser();
            if (user == null)
            {
                TempData["ErrorMessage"] = "To play against AI, you must log in first!";
                return RedirectToAction("Register", "Account");
            }

            ViewData["Username"] = user.Username;
            return View();
        }

        // ✅ Action (HTTP POST) to increment total games via AJAX
        [HttpPost]
        public IActionResult IncrementTotalGames()
        {
            var user = GetLoggedInUser();
            if (user == null)
            {
                return Unauthorized();
            }

            user.TotalGames++;
            _context.SaveChanges();
            return Ok(new { success = true, totalGames = user.TotalGames });
        }

        // ✅ Save AI Match Result (Now Saves Every Round, including Rematches)
        [HttpPost]
        public async Task<IActionResult> SaveAiMatchResult([FromBody] AiMatchResult request)
        {
            var user = GetLoggedInUser();
            if (user == null)
            {
                return Unauthorized(new { message = "User is not logged in." });
            }

            bool isWin = request.Result == "win";

            if (isWin)
            {
                user.RankPoints += 20;  // ✅ Higher rating for beating AI
                user.WinningStreak++;
            }
            else
            {
                user.WinningStreak = 0; // ✅ Reset streak if lost
            }

            user.TotalGames++;

            // ✅ Always Save AI Match History (Including Rematches)
            var match = new MatchHistory
            {
                UserId = user.Id,
                Opponent = "AI (Expert)",  // ✅ Show AI as an opponent
                IsWin = isWin,
                DatePlayed = DateTime.UtcNow
            };

            _context.MatchHistories.Add(match);
            await _context.SaveChangesAsync();

            return Ok(new { message = "AI match history saved successfully." });
        }

    }

    // ✅ DTO for receiving match history data
    public class MatchHistoryRequest
    {
        public string Opponent { get; set; } = string.Empty;
        public string Result { get; set; } = string.Empty;
    }

    public class AiMatchResult
    {
        public string Result { get; set; } = string.Empty; // "win" or "lose"
    }
}
