﻿using Microsoft.EntityFrameworkCore;
using TicTacToe.Models;

namespace TicTacToe.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; } // Represents the Users table
        public DbSet<MatchHistory> MatchHistories { get; set; } // Represents the Match History table

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // ✅ Explicitly specify the User navigation property
            modelBuilder.Entity<MatchHistory>()
                .HasOne(m => m.User) // ✅ Make sure EF Core knows which property to map
                .WithMany(u => u.MatchHistories)
                .HasForeignKey(m => m.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
